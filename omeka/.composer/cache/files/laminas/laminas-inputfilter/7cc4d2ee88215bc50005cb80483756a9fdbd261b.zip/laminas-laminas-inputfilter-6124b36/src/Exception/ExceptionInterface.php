<?php

namespace Laminas\InputFilter\Exception;

interface ExceptionInterface
{
}
