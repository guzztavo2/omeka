<?php

namespace Laminas\InputFilter\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
