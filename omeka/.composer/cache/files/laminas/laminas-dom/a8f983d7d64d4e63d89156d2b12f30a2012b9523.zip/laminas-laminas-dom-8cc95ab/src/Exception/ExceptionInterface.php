<?php

declare(strict_types=1);

namespace Laminas\Dom\Exception;

/**
 * Laminas\Dom Exceptions
 */
interface ExceptionInterface
{
}
