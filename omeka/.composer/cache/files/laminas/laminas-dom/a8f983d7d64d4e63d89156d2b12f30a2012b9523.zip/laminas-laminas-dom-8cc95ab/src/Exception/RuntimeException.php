<?php

declare(strict_types=1);

namespace Laminas\Dom\Exception;

/**
 * Laminas\Dom Exceptions
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
