<?php

declare(strict_types=1);

namespace Laminas\Log\Writer;

/**
 * @deprecated Simply moved to the parent directory
 */
class FormatterPluginManager extends \Laminas\Log\FormatterPluginManager
{
}
