<?php

declare(strict_types=1);

namespace Laminas\Log\Exception;

class ExtensionNotLoadedException extends RuntimeException
{
}
