<?php

declare(strict_types=1);

namespace Laminas\Log\Writer;

/**
 * @deprecated has simply be moved to the parent directory
 */
class FilterPluginManager extends \Laminas\Log\FilterPluginManager
{
}
