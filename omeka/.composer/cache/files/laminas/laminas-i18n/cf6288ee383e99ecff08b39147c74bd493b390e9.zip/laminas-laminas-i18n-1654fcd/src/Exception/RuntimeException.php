<?php

namespace Laminas\I18n\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
