<?php

namespace Laminas\I18n\Exception;

class RangeException extends \RangeException implements ExceptionInterface
{
}
