<?php

namespace Laminas\I18n\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
