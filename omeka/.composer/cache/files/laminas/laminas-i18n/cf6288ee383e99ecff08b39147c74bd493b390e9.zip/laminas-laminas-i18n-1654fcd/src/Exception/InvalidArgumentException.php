<?php

namespace Laminas\I18n\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
