<?php

namespace Laminas\Mvc\I18n\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
