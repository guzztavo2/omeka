<?php

namespace Laminas\Mvc\I18n\Exception;

interface ExceptionInterface
{
}
