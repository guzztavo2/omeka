<?php

namespace Laminas\Http\Exception;

interface ExceptionInterface
{
}
