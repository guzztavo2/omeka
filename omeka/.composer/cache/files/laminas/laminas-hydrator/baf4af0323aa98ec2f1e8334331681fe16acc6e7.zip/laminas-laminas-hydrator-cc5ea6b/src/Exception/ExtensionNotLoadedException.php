<?php

declare(strict_types=1);

namespace Laminas\Hydrator\Exception;

/**
 * Extension not loaded exception
 */
class ExtensionNotLoadedException extends RuntimeException
{
}
