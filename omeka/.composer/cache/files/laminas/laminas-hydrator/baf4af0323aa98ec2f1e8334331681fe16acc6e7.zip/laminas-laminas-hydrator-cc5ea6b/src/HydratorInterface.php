<?php

declare(strict_types=1);

namespace Laminas\Hydrator;

interface HydratorInterface extends HydrationInterface, ExtractionInterface
{
}
