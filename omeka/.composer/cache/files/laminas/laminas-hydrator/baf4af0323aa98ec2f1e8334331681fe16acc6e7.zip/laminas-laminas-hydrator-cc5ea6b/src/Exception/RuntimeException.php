<?php

declare(strict_types=1);

namespace Laminas\Hydrator\Exception;

/**
 * Runtime exception
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
