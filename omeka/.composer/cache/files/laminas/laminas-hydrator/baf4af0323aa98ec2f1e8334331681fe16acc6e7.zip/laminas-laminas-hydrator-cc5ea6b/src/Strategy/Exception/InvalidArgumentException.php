<?php

declare(strict_types=1);

namespace Laminas\Hydrator\Strategy\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
