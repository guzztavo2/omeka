<?php

declare(strict_types=1);

namespace Laminas\Hydrator\Exception;

/**
 * Logic exception
 */
class LogicException extends \LogicException implements ExceptionInterface
{
}
