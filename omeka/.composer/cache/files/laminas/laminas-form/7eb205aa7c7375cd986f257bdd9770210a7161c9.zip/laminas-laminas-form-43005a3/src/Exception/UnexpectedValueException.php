<?php

declare(strict_types=1);

namespace Laminas\Form\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements
    ExceptionInterface
{
}
