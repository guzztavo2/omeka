<?php

declare(strict_types=1);

namespace Laminas\Form\Exception;

class ExtensionNotLoadedException extends DomainException
{
}
