<?php

declare(strict_types=1);

namespace Laminas\Form\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
