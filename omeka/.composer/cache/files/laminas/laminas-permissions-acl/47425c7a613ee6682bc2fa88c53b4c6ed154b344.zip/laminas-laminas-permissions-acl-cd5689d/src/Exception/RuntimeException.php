<?php

namespace Laminas\Permissions\Acl\Exception;

class RuntimeException extends \RuntimeException implements
    ExceptionInterface
{
}
