# laminas-permissions-acl

[![Build Status](https://github.com/laminas/laminas-permissions-acl/actions/workflows/continuous-integration.yml/badge.svg)](https://github.com/laminas/laminas-permissions-acl/actions/workflows/continuous-integration.yml)

Provides a lightweight and flexible access control list (ACL) implementation for
privileges management.

- File issues at https://github.com/laminas/laminas-permissions-acl/issues
- Documentation is at https://docs.laminas.dev/laminas-permissions-acl/
