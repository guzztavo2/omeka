<?php

namespace Laminas\Permissions\Acl\Exception;

interface ExceptionInterface
{
}
