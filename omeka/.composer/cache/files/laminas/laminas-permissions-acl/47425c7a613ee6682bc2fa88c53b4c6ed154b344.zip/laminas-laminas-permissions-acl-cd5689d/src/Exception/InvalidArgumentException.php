<?php

namespace Laminas\Permissions\Acl\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements
    ExceptionInterface
{
}
