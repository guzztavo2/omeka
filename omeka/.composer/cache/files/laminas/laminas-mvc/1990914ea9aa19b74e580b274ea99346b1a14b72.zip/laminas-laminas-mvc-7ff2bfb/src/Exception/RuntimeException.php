<?php

namespace Laminas\Mvc\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
