<?php

namespace Laminas\Mvc\Exception;

class InvalidControllerException extends \Exception implements ExceptionInterface
{
}
