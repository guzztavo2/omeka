<?php

namespace Laminas\Mvc\Exception;

class InvalidPluginException extends \Exception implements ExceptionInterface
{
}
