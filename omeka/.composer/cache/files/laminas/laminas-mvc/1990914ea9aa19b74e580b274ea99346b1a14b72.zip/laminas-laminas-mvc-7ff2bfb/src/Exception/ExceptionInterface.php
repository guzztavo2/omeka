<?php

namespace Laminas\Mvc\Exception;

interface ExceptionInterface
{
}
