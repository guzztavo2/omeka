<?php

namespace Laminas\Mvc\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
