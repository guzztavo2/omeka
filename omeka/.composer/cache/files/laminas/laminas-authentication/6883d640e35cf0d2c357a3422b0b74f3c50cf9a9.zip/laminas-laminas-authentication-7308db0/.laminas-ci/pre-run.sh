#!/bin/bash

set -e

cp .laminas-ci/phpunit.xml phpunit.xml
