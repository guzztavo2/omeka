The logo is © 2010+ Sensio Labs.

Original resolution can be found at <https://github.com/PHP-CS-Fixer/logo>.
