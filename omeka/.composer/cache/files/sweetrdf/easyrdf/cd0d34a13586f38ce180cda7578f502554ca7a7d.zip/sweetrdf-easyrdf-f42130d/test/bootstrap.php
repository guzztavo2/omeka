<?php

require __DIR__.'/../vendor/autoload.php';

error_reporting(\E_ALL);

define('ROOT_PATH', __DIR__.\DIRECTORY_SEPARATOR.'..');
