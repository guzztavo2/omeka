# Docker container for local development

We provide a Docker container to make local development easier.

You can start it by running the following command in your command line:

> make

The container provides a PHP with further tools installed, like:

* Composer
* GraphViz
* raptor2-utils

Everything is directly accessible after loggin into the container.
